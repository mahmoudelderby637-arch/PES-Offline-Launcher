package com.example.pesofflinelauncher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int PICK_GAME = 42;
    private static final String PREFS = "launcher_prefs";
    private static final String KEY_URI = "game_uri";
    private static final String KEY_NAME = "game_name";
    private Uri gameUri;
    private String gameName = "";
    private TextView statusText;
    private TextView gameText;
    private SharedPreferences prefs;

    private int bg = Color.rgb(12, 17, 29);
    private int panel = Color.rgb(24, 33, 51);
    private int accent = Color.rgb(48, 205, 130);
    private int white = Color.rgb(245, 247, 250);
    private int muted = Color.rgb(170, 181, 198);

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        String saved = prefs.getString(KEY_URI, null);
        gameName = prefs.getString(KEY_NAME, "");
        if (saved != null) {
            try { gameUri = Uri.parse(saved); } catch (Exception ignored) {}
        }
        render();
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setGravity(Gravity.CENTER);
        t.setPadding(12, 8, 12, 8);
        return t;
    }

    private Button button(String label, boolean primary) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(16);
        b.setTextColor(primary ? Color.rgb(7, 22, 18) : white);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(primary ? accent : panel));
        b.setPadding(16, 14, 16, 14);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 8, 0, 8);
        b.setLayoutParams(lp);
        return b;
    }

    private void render() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(bg);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(22, 30, 22, 24);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        scroll.addView(root);

        root.addView(text("PES OFFLINE", 13, accent, true));
        TextView title = text("العب الآن", 32, white, true);
        title.setPadding(8, 4, 8, 2);
        root.addView(title);
        root.addView(text("مشغّل بسيط لألعاب PSP المتوافقة", 15, muted, false));

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER);
        card.setPadding(14, 20, 14, 20);
        card.setBackgroundTintList(android.content.res.ColorStateList.valueOf(panel));
        card.setBackgroundColor(panel);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        cp.setMargins(0, 24, 0, 12);
        card.setLayoutParams(cp);
        card.addView(text("⚽", 52, accent, true));
        gameText = text(gameUri == null ? "لم يتم اختيار لعبة بعد" : gameName, 18, white, true);
        card.addView(gameText);
        statusText = text(getPpssppInstalled()
            ? "المحاكي: مثبت"
            : "المحاكي: غير مثبت", 14, getPpssppInstalled() ? accent : muted, false);
        card.addView(statusText);
        root.addView(card);

        Button play = button("▶  العب الآن", true);
        play.setOnClickListener(v -> playNow());
        root.addView(play);

        Button choose = button("اختيار ملف اللعبة (ISO / CSO / CHD)", false);
        choose.setOnClickListener(v -> chooseGame());
        root.addView(choose);

        Button emulator = button(getPpssppInstalled() ? "فتح PPSSPP" : "تثبيت PPSSPP الرسمي", false);
        emulator.setOnClickListener(v -> openOrInstallEmulator());
        root.addView(emulator);

        Button settings = button("الإعدادات والتعليمات", false);
        settings.setOnClickListener(v -> showHelp());
        root.addView(settings);

        root.addView(text("يعمل دون اتصال بعد تثبيت المحاكي واختيار ملف لعبة متوافق. لا تتضمن الحزمة أي لعبة.", 12, muted, false));
        root.addView(text("هذا تطبيق مستقل غير رسمي، وليس تابعًا إلى Sony أو Konami أو PPSSPP.", 11, muted, false));
        setContentView(scroll);
    }

    private boolean getPpssppInstalled() {
        return isPackageInstalled("org.ppsspp.ppsspp") || isPackageInstalled("org.ppsspp.ppssppgold");
    }

    private boolean isPackageInstalled(String pkg) {
        try { getPackageManager().getPackageInfo(pkg, 0); return true; }
        catch (Exception e) { return false; }
    }

    private void chooseGame() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[] {
            "application/octet-stream", "application/x-iso9660-image"
        });
        try { startActivityForResult(intent, PICK_GAME); }
        catch (ActivityNotFoundException e) {
            Toast.makeText(this, "تعذر فتح مدير الملفات على هذا الجهاز.", Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_GAME && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            String name = uri.getLastPathSegment();
            if (name == null || name.trim().isEmpty()) name = "ملف لعبة محدد";
            final String selectedName = name;
            String lower = selectedName.toLowerCase();
            if (!(lower.endsWith(".iso") || lower.endsWith(".cso") || lower.endsWith(".chd"))) {
                new AlertDialog.Builder(this).setTitle("تحقق من الملف")
                    .setMessage("الامتداد المختار ليس ISO أو CSO أو CHD. يمكنك المتابعة فقط إذا كنت متأكدًا أن الملف متوافق.")
                    .setNegativeButton("اختيار ملف آخر", (d, w) -> chooseGame())
                    .setPositiveButton("استخدام الملف", (d, w) -> saveGame(uri, selectedName))
                    .show();
            } else saveGame(uri, selectedName);
        }
    }

    private void saveGame(Uri uri, String name) {
        try {
            final int flags = Intent.FLAG_GRANT_READ_URI_PERMISSION;
            getContentResolver().takePersistableUriPermission(uri, flags);
        } catch (Exception ignored) {}
        gameUri = uri;
        gameName = name;
        prefs.edit().putString(KEY_URI, uri.toString()).putString(KEY_NAME, name).apply();
        render();
        Toast.makeText(this, "تم حفظ اختيار اللعبة.", Toast.LENGTH_SHORT).show();
    }

    private void playNow() {
        if (gameUri == null) {
            new AlertDialog.Builder(this).setTitle("اختَر اللعبة أولًا")
                .setMessage("حدد ملف لعبة PSP تملك حق استخدامه بصيغة ISO أو CSO أو CHD، ثم اضغط «العب الآن».")
                .setPositiveButton("اختيار اللعبة", (d, w) -> chooseGame())
                .setNegativeButton("إلغاء", null).show();
            return;
        }
        if (!getPpssppInstalled()) {
            new AlertDialog.Builder(this).setTitle("المحاكي غير مثبت")
                .setMessage("ثبّت PPSSPP من المصدر الرسمي، ثم ارجع واضغط «العب الآن».")
                .setPositiveButton("فتح صفحة PPSSPP", (d, w) -> openOrInstallEmulator())
                .setNegativeButton("إلغاء", null).show();
            return;
        }
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(gameUri, "*/*");
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        } catch (ActivityNotFoundException | SecurityException e) {
            new AlertDialog.Builder(this).setTitle("تعذر فتح اللعبة مباشرة")
                .setMessage("قد لا يدعم هذا الإصدار من المحاكي فتح الملف المحدد مباشرة. افتح PPSSPP واختر ملف اللعبة من تبويب الألعاب. تأكد من منح المحاكي صلاحية الوصول إلى مجلد اللعبة.")
                .setPositiveButton("فتح PPSSPP", (d, w) -> openOrInstallEmulator())
                .setNegativeButton("حسنًا", null).show();
        }
    }

    private void openOrInstallEmulator() {
        try {
            Intent launch = getPackageManager().getLaunchIntentForPackage("org.ppsspp.ppsspp");
            if (launch == null) launch = getPackageManager().getLaunchIntentForPackage("org.ppsspp.ppssppgold");
            if (launch != null) {
                startActivity(launch);
            } else {
                Intent market = new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=org.ppsspp.ppsspp"));
                startActivity(market);
            }
        } catch (Exception e) {
            Toast.makeText(this, "افتح Google Play وابحث عن PPSSPP - PSP emulator.", Toast.LENGTH_LONG).show();
        }
    }

    private void showHelp() {
        new AlertDialog.Builder(this)
            .setTitle("الإعدادات والتعليمات")
            .setMessage("1) ثبّت PPSSPP من Google Play أو الموقع الرسمي.\n\n2) اختر ملف لعبة PSP بصيغة ISO أو CSO أو CHD تملك حق استخدامها.\n\n3) اضغط «العب الآن». إذا لم يفتح الملف مباشرة، افتح PPSSPP وتصفح إلى مجلد اللعبة.\n\n4) بعد تجهيز المحاكي وملف اللعبة، يمكن لعب الألعاب التي تدعم اللعب الفردي دون إنترنت.\n\nتنبيه: التطبيق لا يحتوي على PES أو أي ملفات ألعاب، ولا يضمن أن كل إصدار PES يعمل بكامل السرعة على كل هاتف.")
            .setPositiveButton("حسنًا", null).show();
    }
}
