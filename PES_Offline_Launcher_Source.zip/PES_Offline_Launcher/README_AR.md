# PES Offline Launcher — مشروع Android

## ما الذي يفعله؟
مشغّل Android بسيط بواجهة عربية يسمح للمستخدم باختيار ملف لعبة PSP بصيغة ISO/CSO/CHD، ثم محاولة فتحه باستخدام PPSSPP. لا يحتوي على لعبة أو BIOS أو ملفات محمية بحقوق النشر.

## قيود مهمة
- هذا ليس إصدار PES الرسمي ولا محاكيًا بحد ذاته.
- التشغيل المباشر يعتمد على إصدار PPSSPP وطريقة تعامل Android معه مع URI المختار. إذا لم يعمل، افتح PPSSPP واختر الملف من مكتبة الألعاب.
- هذا المشروع لا يثبت PPSSPP تلقائيًا؛ يفتح صفحة Google Play الرسمية عند الحاجة.
- لا يمكن ضمان الأداء دون معرفة إصدار اللعبة ومواصفات الهاتف.
- لا يتضمن المشروع اختبارًا على هاتف فعلي. يلزم الاختبار على الجهاز المستهدف قبل اعتبار التثبيت والتشغيل مؤكدين.

## البناء
افتح المشروع في Android Studio حديث، ثم اختر Build > Build APK(s). أو شغّل:
`gradle assembleDebug`

ملف APK الناتج عادة:
`app/build/outputs/apk/debug/app-debug.apk`

## بناء APK عبر GitHub Actions
ارفع المشروع إلى مستودع GitHub وشغّل workflow الموجود في `.github/workflows/android.yml`. سيبني APK تجريبيًا ويرفقه كـ workflow artifact.

## الاستخدام على الهاتف
1. ثبّت PPSSPP من Google Play: https://play.google.com/store/apps/details?id=org.ppsspp.ppsspp
2. جهّز ملف لعبة PSP تملك حق استخدامها.
3. ثبّت APK الخاص بالمشغّل.
4. اختر ملف اللعبة، ثم جرّب «العب الآن».
5. إذا لم يفتح الملف مباشرة، افتح PPSSPP وتصفح إلى مجلد اللعبة.

المصدر الرسمي لإرشادات PPSSPP:
https://www.ppsspp.org/docs/getting-started/installing-games-android/
https://www.ppsspp.org/docs/reference/command-line/
